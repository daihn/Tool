﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;

namespace ConsoleApplication10
{
    class Program
    {
        static int Main(string[] args)
        {
            for (int i=0; i < 3; i++)
            {
                string Path = "\\\\" + "10.1.130.67" + "\\root\\cimv2:Win32_Service";
                string ServiceName = "EMSEntServer";

                ManagementClass ManagementClass = new ManagementClass(Path);
                Console.WriteLine(Path);
                ConnectionOptions CO = new ConnectionOptions();
                CO.Username = "Administrator";
                CO.Password = "zxcvbASDFG123";
                ManagementScope ManagementScope = new ManagementScope("\\\\" + "10.1.130.67" + "\\root\\cimv2", CO);
                ManagementClass.Scope = ManagementScope;

                int count = 0;
                try
                {
                    foreach (ManagementObject MO in ManagementClass.GetInstances())
                    {
                        count++;
                        if (MO["Name"].ToString() == ServiceName)
                        {
                            string tempState = MO["State"].ToString();
                            if (tempState.Equals("Running"))
                            {
                                int a = count;
                                break;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                System.Threading.Thread.Sleep(1000);
            }

            return 0;
        }
    }
}
